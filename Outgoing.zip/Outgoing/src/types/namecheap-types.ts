
// تعريف أنواع النطاقات
export type DomainStatus = "active" | "expired" | "expiring" | "pending" | "transferred";
export type DomainPrivacy = "enabled" | "disabled";
export type DomainAutorenew = "enabled" | "disabled";

export interface Domain {
  id: string;
  name: string;
  extension: string;
  registrationDate: string;
  expiryDate: string;
  status: DomainStatus;
  privacy: DomainPrivacy;
  autorenew: DomainAutorenew;
  nameservers: string[];
  purchasePrice: number;
  renewPrice: number;
  owner: string;
}

// تعريف أنواع خطط الاستضافة
export type HostingStatus = "active" | "suspended" | "pending" | "canceled";
export type HostingType = "shared" | "reseller" | "vps" | "dedicated" | "wordpress";

export interface HostingPlan {
  id: string;
  name: string;
  type: HostingType;
  domains: number;
  storage: number; // بالجيجابايت
  bandwidth: number; // بالجيجابايت
  monthlyPrice: number;
  yearlyPrice: number;
  cpuCores?: number;
  ram?: number; // بالجيجابايت
  ssdDrive?: boolean;
  features: string[];
}

export interface HostingAccount {
  id: string;
  planId: string;
  planName: string;
  domains: string[];
  purchaseDate: string;
  expiryDate: string;
  status: HostingStatus;
  autorenew: DomainAutorenew;
  username: string;
  serverIp: string;
  controlPanel: string;
  purchasePrice: number;
  renewPrice: number;
  owner: string;
}

// تعريف أنواع الخدمات الإضافية
export type SSLType = "positive" | "essential" | "organization" | "ev";
export type SSLStatus = "active" | "expired" | "pending" | "revoked";

export interface SSL {
  id: string;
  domain: string;
  type: SSLType;
  issueDate: string;
  expiryDate: string;
  status: SSLStatus;
  autorenew: DomainAutorenew;
  purchasePrice: number;
  renewPrice: number;
  owner: string;
}

// تعريف نوع الإحصائيات
export interface NamecheapStats {
  totalDomains: number;
  activeDomains: number;
  expiringDomains: number;
  totalHosting: number;
  activeHosting: number;
  totalSSL: number;
  activeSSL: number;
  totalSpent: number;
}
