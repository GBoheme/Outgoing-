
import React, { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import Sidebar from "@/components/Sidebar";
import { useAuth } from "@/hooks/useAuth";
import { useSettings } from "@/hooks/useSettings";
import { useDocuments } from "@/hooks/useDocuments";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import UserDocumentsTable from "@/components/user/UserDocumentsTable";
import UploadDocument from "@/components/user/UploadDocument";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from "recharts";
import { FilePenLine, FileBarChart, User, Clock, FileText } from "lucide-react";
import { format } from "date-fns";
import { enUS } from "date-fns/locale";

const UserDashboard = () => {
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    const savedState = localStorage.getItem("sidebarState");
    return savedState !== null ? savedState === 'open' : true;
  });

  const { user, isAuthenticated, isLoading } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Log the current user information and location for debugging
  console.log("Current user:", user);
  console.log("Current location:", location.pathname, "Current tab:", getTabFromUrl());
  
  // Get documents without filtering by user to show all documents
  const { documentsStats, isLoading: docsLoading } = useDocuments();

  // Get tab from URL
  function getTabFromUrl() {
    const searchParams = new URLSearchParams(location.search);
    return searchParams.get('tab') || 'dashboard';
  }

  const activeTab = getTabFromUrl();
  
  // Handle tab change with immediate navigation
  const handleTabChange = (value: string) => {
    console.log(`Tab changed to: ${value}`);
    navigate(`/user?tab=${value}`, { replace: true });
  };

  // Listen for external changes to sidebar state
  useEffect(() => {
    const handleSidebarStateChanged = () => {
      const currentState = localStorage.getItem('sidebarState');
      setSidebarOpen(currentState === 'open');
    };
    
    window.addEventListener('sidebarStateChanged', handleSidebarStateChanged);
    
    return () => {
      window.removeEventListener('sidebarStateChanged', handleSidebarStateChanged);
    };
  }, []);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate, isLoading]);

  // Toggle sidebar function
  const toggleSidebar = () => {
    const newState = !sidebarOpen;
    setSidebarOpen(newState);
    localStorage.setItem('sidebarState', newState ? 'open' : 'closed');
    
    // Dispatch custom event to notify other components
    const event = new CustomEvent('sidebarStateChanged');
    window.dispatchEvent(event);
  };

  // Get current time to customize greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 6) return "مساء الخير";
    if (hour < 12) return "صباح الخير";
    if (hour < 17) return "ظهيرة سعيدة";
    return "مساء الخير";
  };

  // Data for stats and charts based on actual document counts
  const documentTypesData = [
    { name: 'وارد', value: documentsStats?.inboundCount || 0, color: '#D4AF37' },
    { name: 'صادر', value: documentsStats?.outboundCount || 0, color: '#3b82f6' },
  ];

  // Updated to show empty data if no activity
  const hasRecentActivity = (documentsStats?.total || 0) > 0;
  const recentActivityData = hasRecentActivity ? [
    { name: 'السبت', وارد: 4, صادر: 2 },
    { name: 'الأحد', وارد: 3, صادر: 1 },
    { name: 'الإثنين', وارد: 2, صادر: 3 },
    { name: 'الثلاثاء', وارد: 5, صادر: 2 },
    { name: 'الأربعاء', وارد: 3, صادر: 4 },
    { name: 'الخميس', وارد: 2, صادر: 1 },
    { name: 'الجمعة', وارد: 0, صادر: 0 },
  ] : Array(7).fill(0).map((_, index) => {
    const days = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
    return { name: days[index], وارد: 0, صادر: 0 };
  });

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#1A1F2C] dark:bg-background transition-colors duration-300">
        <div className="w-16 h-16 border-4 border-[#D4AF37] dark:border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // Format current date for last update display
  const currentDate = format(new Date(), "MMM dd, yyyy", { locale: enUS });
  const currentTime = format(new Date(), "h:mm a", { locale: enUS });

  return (
    <div className="min-h-screen bg-[#1A1F2C] dark:bg-background text-white transition-colors duration-300" dir="rtl">
      <Navbar
        userName={user.fullName}
        userRole="مستخدم"
        sidebarOpen={sidebarOpen}
        toggleSidebar={toggleSidebar}
      />
      
      <div className="flex">
        <Sidebar 
          isOpen={sidebarOpen} 
          userRole="user" 
          toggleSidebar={toggleSidebar}
        />
        
        <div 
          className={`flex-1 p-4 transition-all duration-300 ${
            sidebarOpen ? 'md:mr-64' : 'md:mr-20'
          }`}
        >
          <Card className="mb-6 bg-[#221F26] dark:bg-card border-[#3A3A3C] dark:border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-[#D4AF37] dark:text-primary text-xl font-cairo">
                {getGreeting()}, <span className="font-bold">{user.fullName}</span>
              </CardTitle>
              <CardDescription className="text-gray-300 dark:text-muted-foreground font-cairo">
                أهلاً بك في {settings?.companyName || "نظام إدارة الوثائق"} - لوحة تحكم المستخدم
              </CardDescription>
            </CardHeader>
            <CardContent className="text-sm text-gray-400">
              <p>يمكنك من هنا رفع وإدارة وثائقك بكل سهولة</p>
            </CardContent>
            <CardFooter className="pt-0">
              <Link 
                to="/profile" 
                className="text-[#D4AF37] dark:text-primary text-sm hover:underline flex items-center gap-1"
              >
                <User size={16} /> إدارة الملف الشخصي
              </Link>
            </CardFooter>
          </Card>
          
          <Tabs value={activeTab} className="w-full" onValueChange={handleTabChange}>
            <TabsList className="grid grid-cols-3 gap-2 mb-6 bg-[#221F26] dark:bg-secondary">
              <TabsTrigger value="dashboard" className="font-cairo data-[state=active]:bg-[#D4AF37] dark:data-[state=active]:bg-primary data-[state=active]:text-black dark:data-[state=active]:text-black">
                لوحة المعلومات
              </TabsTrigger>
              <TabsTrigger value="upload" className="font-cairo data-[state=active]:bg-[#D4AF37] dark:data-[state=active]:bg-primary data-[state=active]:text-black dark:data-[state=active]:text-black">
                رفع وثيقة جديدة
              </TabsTrigger>
              <TabsTrigger value="documents" className="font-cairo data-[state=active]:bg-[#D4AF37] dark:data-[state=active]:bg-primary data-[state=active]:text-black dark:data-[state=active]:text-black">
                وثائقي
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="dashboard" className="transition-all duration-300 animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {/* إحصائيات الوثائق */}
                <Card className="bg-gradient-to-br from-[#221F26] to-blue-500/5 dark:from-card border-[#3A3A3C] dark:border-border overflow-hidden relative">
                  <div className="absolute top-0 left-0 w-full h-1 bg-blue-400"></div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-cairo flex items-center gap-2">
                      <FileText className="text-[#D4AF37] dark:text-primary" size={18} />
                      <span>إجمالي الوثائق</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-[#D4AF37] dark:text-primary">
                      {docsLoading ? "..." : documentsStats?.total || 0}
                    </p>
                    <p className="text-sm text-gray-400">وثيقة مسجلة</p>
                  </CardContent>
                </Card>
                
                {/* إحصائيات الوارد */}
                <Card className="bg-gradient-to-br from-[#221F26] to-green-500/5 dark:from-card border-[#3A3A3C] dark:border-border overflow-hidden relative">
                  <div className="absolute top-0 left-0 w-full h-1 bg-green-400"></div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-cairo flex items-center gap-2">
                      <FilePenLine className="text-[#D4AF37] dark:text-primary" size={18} />
                      <span>الوثائق الواردة</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-[#D4AF37] dark:text-primary">
                      {docsLoading ? "..." : documentsStats?.inboundCount || 0}
                    </p>
                    <p className="text-sm text-gray-400">
                      آخر وارد: {documentsStats?.inboundCount > 0 ? documentsStats?.lastInboundRef : "لا يوجد"}
                    </p>
                  </CardContent>
                </Card>
                
                {/* إحصائيات الصادر */}
                <Card className="bg-gradient-to-br from-[#221F26] to-amber-500/5 dark:from-card border-[#3A3A3C] dark:border-border overflow-hidden relative">
                  <div className="absolute top-0 left-0 w-full h-1 bg-amber-400"></div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-cairo flex items-center gap-2">
                      <FileBarChart className="text-[#D4AF37] dark:text-primary" size={18} />
                      <span>الوثائق الصادرة</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-[#D4AF37] dark:text-primary">
                      {docsLoading ? "..." : documentsStats?.outboundCount || 0}
                    </p>
                    <p className="text-sm text-gray-400">
                      آخر صادر: {documentsStats?.outboundCount > 0 ? documentsStats?.lastOutboundRef : "لا يوجد"}
                    </p>
                  </CardContent>
                </Card>
                
                {/* وقت آخر تحديث */}
                <Card className="bg-gradient-to-br from-[#221F26] to-purple-500/5 dark:from-card border-[#3A3A3C] dark:border-border overflow-hidden relative">
                  <div className="absolute top-0 left-0 w-full h-1 bg-purple-400"></div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-cairo flex items-center gap-2">
                      <Clock className="text-[#D4AF37] dark:text-primary" size={18} />
                      <span>آخر تحديث</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xl font-bold text-[#D4AF37] dark:text-primary">
                      {currentDate}
                    </p>
                    <p className="text-sm text-gray-400">{currentTime}</p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                {/* رسم بياني دائري لأنواع الوثائق */}
                <Card className="bg-[#221F26] dark:bg-card border-[#3A3A3C] dark:border-border">
                  <CardHeader>
                    <CardTitle className="text-lg font-cairo">توزيع أنواع الوثائق</CardTitle>
                    <CardDescription className="text-gray-400">نسبة الوثائق الواردة والصادرة</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[300px] flex items-center justify-center">
                    {(documentsStats?.total || 0) > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={documentTypesData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {documentTypesData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex flex-col items-center justify-center text-gray-400 h-full">
                        <FileText size={48} className="mb-2 opacity-25" />
                        <p className="text-lg">لا توجد وثائق لعرضها</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {/* رسم بياني شريطي للنشاط الأخير */}
                <Card className="bg-[#221F26] dark:bg-card border-[#3A3A3C] dark:border-border">
                  <CardHeader>
                    <CardTitle className="text-lg font-cairo">نشاط الأسبوع الأخير</CardTitle>
                    <CardDescription className="text-gray-400">توزيع الوثائق الواردة والصادرة</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[300px]">
                    {hasRecentActivity ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={recentActivityData}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="وارد" fill="#D4AF37" />
                          <Bar dataKey="صادر" fill="#3b82f6" />
                        </BarChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex flex-col items-center justify-center text-gray-400 h-full">
                        <Clock size={48} className="mb-2 opacity-25" />
                        <p className="text-lg">لا يوجد نشاط حديث لعرضه</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="upload" className="transition-all duration-300 animate-fade-in">
              <UploadDocument />
            </TabsContent>
            
            <TabsContent value="documents" className="transition-all duration-300 animate-fade-in">
              <UserDocumentsTable />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
