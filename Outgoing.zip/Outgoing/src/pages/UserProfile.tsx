
import React, { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import Sidebar from "@/components/Sidebar";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { Card, CardHeader, CardContent, CardFooter, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { ShieldCheck, User, Settings, Bell, Moon, Sun } from "lucide-react";
import { ThemeSwitcher } from "@/components/ThemeSwitcher";

const UserProfile = () => {
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    const savedState = localStorage.getItem("sidebarState");
    return savedState !== null ? savedState === 'open' : true;
  });

  const { user, isAuthenticated, isLoading, updateUser, changePassword } = useAuth();
  const { theme } = useTheme();
  const navigate = useNavigate();
  
  // Restore userData state that was accidentally removed
  const [userData, setUserData] = useState({
    fullName: "",
    email: "",
    phone: "",
    department: "",
  });
  
  // حالة إدارة كلمة المرور
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [passwordError, setPasswordError] = useState("");
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);

  // حالة إعدادات الإشعارات
  const [notificationSettings, setNotificationSettings] = useState({
    documentNotifications: true,
    emailNotifications: true,
  });

  // حالة إعدادات الأمان
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: false,
  });
  
  // تحميل بيانات المستخدم
  useEffect(() => {
    if (user) {
      setUserData({
        fullName: user.fullName || "",
        email: user.email || "",
        phone: user.phone || "",
        department: user.department || "",
      });
    }
  }, [user]);

  // الاستماع للتغييرات في حالة الشريط الجانبي
  useEffect(() => {
    const handleSidebarStateChanged = () => {
      const currentState = localStorage.getItem('sidebarState');
      setSidebarOpen(currentState === 'open');
    };
    
    window.addEventListener('sidebarStateChanged', handleSidebarStateChanged);
    
    return () => {
      window.removeEventListener('sidebarStateChanged', handleSidebarStateChanged);
    };
  }, []);

  // التحقق من تسجيل الدخول
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate, isLoading]);

  // تبديل حالة الشريط الجانبي
  const toggleSidebar = () => {
    const newState = !sidebarOpen;
    setSidebarOpen(newState);
    localStorage.setItem('sidebarState', newState ? 'open' : 'closed');
    
    // إطلاق حدث مخصص لإشعار المكونات الأخرى
    const event = new CustomEvent('sidebarStateChanged');
    window.dispatchEvent(event);
  };

  // تحديث بيانات المستخدم
  const handleUpdateProfile = async () => {
    const success = await updateUser({
      fullName: userData.fullName,
      email: userData.email,
      phone: userData.phone,
      department: userData.department,
    });
    
    if (success) {
      toast.success("تم تحديث الملف الشخصي", {
        description: "تم تحديث بياناتك الشخصية بنجاح"
      });
    }
  };

  // التعامل مع تغييرات كلمة المرور
  const handlePasswordChange = async () => {
    setPasswordError("");
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setPasswordError("كلمات المرور غير متطابقة");
      return;
    }
    
    if (passwordData.newPassword.length < 6) {
      setPasswordError("يجب أن تكون كلمة المرور 6 أحرف على الأقل");
      return;
    }
    
    const success = await changePassword(
      passwordData.currentPassword,
      passwordData.newPassword
    );
    
    if (success) {
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setShowPasswordDialog(false);
    }
  };

  // تحديث إعدادات الإشعارات
  const handleNotificationSettingsChange = (setting: keyof typeof notificationSettings) => {
    const newSettings = {
      ...notificationSettings,
      [setting]: !notificationSettings[setting],
    };
    
    setNotificationSettings(newSettings);
    
    // هنا يمكن إضافة كود لحفظ التغييرات في قاعدة البيانات
    toast.success("تم تحديث إعدادات الإشعارات");
  };

  // تحديث إعدادات الأمان
  const handleSecuritySettingsChange = (setting: keyof typeof securitySettings) => {
    const newSettings = {
      ...securitySettings,
      [setting]: !securitySettings[setting],
    };
    
    setSecuritySettings(newSettings);
    
    // هنا يمكن إضافة كود لحفظ التغييرات في قاعدة البيانات
    if (newSettings.twoFactorAuth) {
      toast.success("تم تفعيل المصادقة الثنائية");
    } else {
      toast.info("تم إيقاف المصادقة الثنائية");
    }
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background transition-colors duration-300">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300" dir="rtl">
      <Navbar
        userName={user.fullName}
        userRole={user.role === "admin" ? "مدير النظام" : "مستخدم"}
        sidebarOpen={sidebarOpen}
        toggleSidebar={toggleSidebar}
      />
      
      <div className="flex">
        <Sidebar 
          isOpen={sidebarOpen} 
          userRole={user.role} 
          toggleSidebar={toggleSidebar}
        />
        
        <div 
          className={`flex-1 p-4 transition-all duration-300 ${
            sidebarOpen ? 'md:mr-64' : 'md:mr-20'
          }`}
        >
          <h1 className="text-2xl font-bold mb-6 font-cairo">
            الملف الشخصي <span className="text-primary">{user.fullName}</span>
          </h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* بطاقة الملف الشخصي */}
            <Card className="bg-card border-border text-foreground col-span-1 md:col-span-2">
              <CardHeader>
                <CardTitle className="text-xl font-cairo text-primary flex items-center gap-2">
                  <User className="w-5 h-5" /> المعلومات الشخصية
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  قم بتحديث بياناتك الشخصية
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">الاسم الكامل</label>
                  <Input 
                    value={userData.fullName}
                    onChange={(e) => setUserData({...userData, fullName: e.target.value})}
                    className="bg-background border-input text-foreground"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">البريد الإلكتروني</label>
                  <Input 
                    value={userData.email}
                    onChange={(e) => setUserData({...userData, email: e.target.value})}
                    className="bg-background border-input text-foreground"
                    type="email"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">رقم الهاتف</label>
                  <Input 
                    value={userData.phone}
                    onChange={(e) => setUserData({...userData, phone: e.target.value})}
                    className="bg-background border-input text-foreground"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">القسم/الإدارة</label>
                  <Input 
                    value={userData.department}
                    onChange={(e) => setUserData({...userData, department: e.target.value})}
                    className="bg-background border-input text-foreground"
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={handleUpdateProfile}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
                >
                  حفظ التغييرات
                </Button>
              </CardFooter>
            </Card>
            
            {/* بطاقة الإعدادات */}
            <Card className="bg-card border-border text-foreground">
              <CardHeader>
                <CardTitle className="text-xl font-cairo text-primary flex items-center gap-2">
                  <Settings className="w-5 h-5" /> الإعدادات
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  تخصيص إعدادات التطبيق
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="theme" className="border-border">
                    <AccordionTrigger className="text-foreground hover:text-primary">
                      <span className="flex items-center gap-2">
                        <Sun className="w-4 h-4" /> السمة والألوان
                      </span>
                    </AccordionTrigger>
                    <AccordionContent className="pt-2">
                      <div className="flex items-center justify-between">
                        <span>السمة الحالية</span>
                        <ThemeSwitcher />
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="notifications" className="border-border">
                    <AccordionTrigger className="text-foreground hover:text-primary">
                      <span className="flex items-center gap-2">
                        <Bell className="w-4 h-4" /> الإشعارات
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span>إشعارات الوثائق الجديدة</span>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={notificationSettings.documentNotifications}
                              onChange={() => handleNotificationSettingsChange('documentNotifications')} 
                              className="sr-only peer" 
                            />
                            <div className="w-11 h-6 bg-gray-500 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                          </label>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>إشعارات البريد الإلكتروني</span>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={notificationSettings.emailNotifications}
                              onChange={() => handleNotificationSettingsChange('emailNotifications')} 
                              className="sr-only peer" 
                            />
                            <div className="w-11 h-6 bg-gray-500 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                          </label>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="security" className="border-border">
                    <AccordionTrigger className="text-foreground hover:text-primary">
                      <span className="flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4" /> الأمان
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-3">
                        <Button 
                          variant="outline" 
                          className="w-full bg-background text-foreground hover:bg-secondary/80 hover:text-foreground"
                          onClick={() => setShowPasswordDialog(true)}
                        >
                          تغيير كلمة المرور
                        </Button>
                        <div className="flex items-center justify-between">
                          <span>المصادقة الثنائية</span>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={securitySettings.twoFactorAuth}
                              onChange={() => handleSecuritySettingsChange('twoFactorAuth')} 
                              className="sr-only peer" 
                            />
                            <div className="w-11 h-6 bg-gray-500 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                          </label>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </div>
          
          {/* حوار تغيير كلمة المرور */}
          <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
            <DialogContent className="bg-card border-border text-foreground">
              <DialogHeader>
                <DialogTitle className="text-xl font-cairo">تغيير كلمة المرور</DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  أدخل كلمة المرور الحالية وكلمة المرور الجديدة.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium">كلمة المرور الحالية</label>
                  <Input 
                    type="password" 
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                    className="bg-background border-input text-foreground" 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">كلمة المرور الجديدة</label>
                  <Input 
                    type="password" 
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                    className="bg-background border-input text-foreground" 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">تأكيد كلمة المرور الجديدة</label>
                  <Input 
                    type="password" 
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                    className="bg-background border-input text-foreground" 
                  />
                </div>
                {passwordError && (
                  <p className="text-red-500 text-sm">{passwordError}</p>
                )}
              </div>
              <DialogFooter>
                <Button 
                  variant="outline"
                  onClick={() => setShowPasswordDialog(false)}
                  className="bg-secondary/30 hover:bg-secondary/50 text-foreground"
                >
                  إلغاء
                </Button>
                <Button 
                  onClick={handlePasswordChange}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  تحديث كلمة المرور
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
